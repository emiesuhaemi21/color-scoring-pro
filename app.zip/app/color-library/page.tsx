"use client";

import { useEffect, useState } from "react";
import { ColorPackage, ColorEntry, LibraryType } from "@/types/color-library";

// Fungsi konversi LAB ke sRGB (0-255)
function labToRgb(l: number, a: number, b: number) {
  // LAB → XYZ
  let y = (l + 16) / 116;
  let x = a / 500 + y;
  let z = y - b / 200;

  const xyz2 = (v: number) => (v ** 3 > 0.008856 ? v ** 3 : (v - 16 / 116) / 7.787);
  x = xyz2(x) * 0.95047;
  y = xyz2(y) * 1.0;
  z = xyz2(z) * 1.08883;

  // XYZ → linear RGB
  let r = x * 3.2406 + y * -1.5372 + z * -0.4986;
  let g = x * -0.9689 + y * 1.8758 + z * 0.0415;
  let b_ = x * 0.0557 + y * -0.2040 + z * 1.0570;

  const gamma = (c: number) => {
    c = c <= 0 ? 0 : c >= 1 ? 1 : c;
    return c <= 0.0031308 ? 12.92 * c : 1.055 * c ** (1 / 2.4) - 0.055;
  };

  r = Math.round(gamma(r) * 255);
  g = Math.round(gamma(g) * 255);
  b_ = Math.round(gamma(b_) * 255);

  return [r, g, b_];
}

export default function ColorLibraryPage() {
  const [packages, setPackages] = useState<ColorPackage[]>([]);
  const [colors, setColors] = useState<ColorEntry[]>([]);
  const [selectedPackage, setSelectedPackage] = useState<number>(1);

  // Package state
  const [showAddPackage, setShowAddPackage] = useState(false);
  const [newPackageName, setNewPackageName] = useState("");
  const [newPackageType, setNewPackageType] = useState<LibraryType>("Standard");
  const [editingPackageId, setEditingPackageId] = useState<number | null>(null);
  const [editPackageName, setEditPackageName] = useState("");
  const [editPackageType, setEditPackageType] = useState<LibraryType>("Standard");

  // Color state
  const [showAddColor, setShowAddColor] = useState(false);
  const [newColorName, setNewColorName] = useState("");
  const [newL, setNewL] = useState("");
  const [newA, setNewA] = useState("");
  const [newB, setNewB] = useState("");

  const [editingColorId, setEditingColorId] = useState<number | null>(null);
  const [editColorName, setEditColorName] = useState("");
  const [editL, setEditL] = useState("");
  const [editA, setEditA] = useState("");
  const [editB, setEditB] = useState("");

  // Load default / localStorage
  useEffect(() => {
    const savedPackages = localStorage.getItem("color-packages");
    const savedColors = localStorage.getItem("color-library-colors");

    if (savedPackages) setPackages(JSON.parse(savedPackages));
    else setPackages([
      { id: 1, type: "Standard", name: "Quick Standard", description: "Basic process colors" },
      { id: 2, type: "Standard", name: "FOGRA39", description: "FOGRA reference" },
      { id: 3, type: "Standard", name: "ISO Coated V2", description: "ISO reference" },
    ]);

    if (savedColors) setColors(JSON.parse(savedColors));
    else setColors([
      { id: 1, packageId: 1, name: "Process Cyan", l: 55, a: -35, b: -50 },
      { id: 2, packageId: 1, name: "Process Magenta", l: 48, a: 74, b: -5 },
      { id: 3, packageId: 1, name: "Process Yellow", l: 90, a: -5, b: 90 },
      { id: 4, packageId: 1, name: "Process Black", l: 20, a: 0, b: 0 },
    ]);
  }, []);

  useEffect(() => localStorage.setItem("color-packages", JSON.stringify(packages)), [packages]);
  useEffect(() => localStorage.setItem("color-library-colors", JSON.stringify(colors)), [colors]);

  const filteredColors = colors.filter(c => c.packageId === selectedPackage);

  const addColor = () => {
    if (!newColorName || newL === "" || newA === "" || newB === "") return alert("Fill all fields");
    if (isNaN(Number(newL)) || isNaN(Number(newA)) || isNaN(Number(newB))) return alert("L, a, b must be numbers");
    const newColor: ColorEntry = {
      id: Date.now(),
      packageId: selectedPackage,
      name: newColorName,
      l: Number(newL),
      a: Number(newA),
      b: Number(newB),
    };
    setColors([...colors, newColor]);
    setNewColorName(""); setNewL(""); setNewA(""); setNewB(""); setShowAddColor(false);
  };

  const deleteColor = (id: number) => {
    if (!confirm("Delete this color?")) return;
    setColors(colors.filter(c => c.id !== id));
  };

  const startEditColor = (color: ColorEntry) => {
    setEditingColorId(color.id);
    setEditColorName(color.name);
    setEditL(color.l.toString());
    setEditA(color.a.toString());
    setEditB(color.b.toString());
    setShowAddColor(true);
  };

  const saveEditColor = () => {
    if (editingColorId === null) return;
    setColors(colors.map(c =>
      c.id === editingColorId
        ? { ...c, name: editColorName, l: Number(editL), a: Number(editA), b: Number(editB) }
        : c
    ));
    setEditingColorId(null); setEditColorName(""); setEditL(""); setEditA(""); setEditB(""); setShowAddColor(false);
  };

  return (
    <main className="p-8">
      <h1 className="text-3xl font-bold mb-6">COLOR LIBRARY</h1>

      {/* Add Package */}
      <button onClick={() => setShowAddPackage(true)} className="bg-green-600 text-white px-4 py-2 rounded-xl mb-4">+ New Package</button>

      {/* Add Package Form */}
      {showAddPackage && (
        <div className="border rounded-xl p-4 mb-4 space-y-2">
          <input type="text" placeholder="Package Name" value={newPackageName} onChange={e => setNewPackageName(e.target.value)} className="border p-2 rounded w-full"/>
          <select value={newPackageType} onChange={e => setNewPackageType(e.target.value as LibraryType)} className="border p-2 rounded w-full">
            <option value="Standard">Standard</option>
            <option value="Customer">Customer</option>
            <option value="Job">Job</option>
            <option value="Pantone">Pantone</option>
          </select>
          <div className="flex gap-2">
            <button onClick={() => {
              setPackages([...packages, { id: Date.now(), name: newPackageName, type: newPackageType, description: "Custom Package" }]);
              setNewPackageName(""); setNewPackageType("Standard"); setShowAddPackage(false);
            }} className="bg-green-600 text-white px-4 py-2 rounded">Add Package</button>
            <button onClick={() => setShowAddPackage(false)} className="bg-gray-400 text-white px-4 py-2 rounded">Cancel</button>
          </div>
        </div>
      )}

      {/* Packages List */}
      <div className="space-y-3">
        {packages.map(pkg => (
          <div key={pkg.id} className={`border rounded-xl p-4 ${selectedPackage === pkg.id ? "border-cyan-500 bg-cyan-50" : ""}`}>
            <div className="flex justify-between items-center">
              <div onClick={() => setSelectedPackage(pkg.id)} className="cursor-pointer">
                <div className="font-bold text-lg">{pkg.name}</div>
                <div className="text-sm opacity-70">{pkg.type}</div>
                <p className="mt-1">{pkg.description}</p>
              </div>
              <div className="flex gap-2">
                <button onClick={() => { setEditingPackageId(pkg.id); setEditPackageName(pkg.name); setEditPackageType(pkg.type); }} className="bg-blue-500 text-white px-3 py-1 rounded text-sm">Edit</button>
                <button onClick={() => { setPackages(packages.filter(p => p.id !== pkg.id)); setColors(colors.filter(c => c.packageId !== pkg.id)); }} className="bg-red-500 text-white px-3 py-1 rounded text-sm">Delete</button>
              </div>
            </div>

            {/* Inline Edit Package Form */}
            {editingPackageId === pkg.id && (
              <div className="border rounded-xl p-4 mt-2 space-y-2">
                <input type="text" value={editPackageName} onChange={e => setEditPackageName(e.target.value)} className="border p-2 rounded w-full"/>
                <select value={editPackageType} onChange={e => setEditPackageType(e.target.value as LibraryType)} className="border p-2 rounded w-full">
                  <option value="Standard">Standard</option>
                  <option value="Customer">Customer</option>
                  <option value="Job">Job</option>
                  <option value="Pantone">Pantone</option>
                </select>
                <div className="flex gap-2">
                  <button onClick={() => { setPackages(packages.map(p => p.id === editingPackageId ? {...p, name: editPackageName, type: editPackageType} : p)); setEditingPackageId(null); }} className="bg-green-600 text-white px-4 py-2 rounded">Save</button>
                  <button onClick={() => setEditingPackageId(null)} className="bg-gray-400 text-white px-4 py-2 rounded">Cancel</button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Colors Section */}
      <div className="mt-10">
        <div className="mb-4 font-bold">Package Selected: {packages.find(p => p.id === selectedPackage)?.name}</div>
        <h2 className="text-2xl font-bold mb-4">COLORS</h2>

        <button onClick={() => setShowAddColor(true)} className="bg-cyan-500 text-white px-4 py-2 rounded-xl mb-4">+ Add Color</button>

        {/* Add Color Form */}
        {showAddColor && editingColorId === null && (
          <div className="border rounded-xl p-4 mb-4 space-y-2">
            <input type="text" placeholder="Color Name" value={newColorName} onChange={e => setNewColorName(e.target.value)} className="border p-2 rounded w-full"/>
            <input type="number" placeholder="L" value={newL} onChange={e => setNewL(e.target.value)} className="border p-2 rounded w-full"/>
            <input type="number" placeholder="a" value={newA} onChange={e => setNewA(e.target.value)} className="border p-2 rounded w-full"/>
            <input type="number" placeholder="b" value={newB} onChange={e => setNewB(e.target.value)} className="border p-2 rounded w-full"/>
            <div className="flex gap-2">
              <button onClick={addColor} className="bg-green-600 text-white px-4 py-2 rounded">Add Color</button>
              <button onClick={() => setShowAddColor(false)} className="bg-gray-400 text-white px-4 py-2 rounded">Cancel</button>
            </div>
          </div>
        )}

        {/* Edit Color Form */}
        {editingColorId !== null && (
          <div className="border rounded-xl p-4 mb-4 space-y-2">
            <input type="text" placeholder="Color Name" value={editColorName} onChange={e => setEditColorName(e.target.value)} className="border p-2 rounded w-full"/>
            <input type="number" placeholder="L" value={editL} onChange={e => setEditL(e.target.value)} className="border p-2 rounded w-full"/>
            <input type="number" placeholder="a" value={editA} onChange={e => setEditA(e.target.value)} className="border p-2 rounded w-full"/>
            <input type="number" placeholder="b" value={editB} onChange={e => setEditB(e.target.value)} className="border p-2 rounded w-full"/>
            <div className="flex gap-2">
              <button onClick={saveEditColor} className="bg-green-600 text-white px-4 py-2 rounded">Save</button>
              <button onClick={() => setEditingColorId(null)} className="bg-gray-400 text-white px-4 py-2 rounded">Cancel</button>
            </div>
          </div>
        )}

        {/* Color Cards */}
        {filteredColors.map(color => {
          const [r, g, b_] = labToRgb(color.l, color.a, color.b);
          return (
            <div key={color.id} className="border rounded-xl p-3 mb-2 flex justify-between items-center">
              <div>
                <div className="font-bold">{color.name}</div>
                <div>L {color.l} | a {color.a} | b {color.b}</div>
              </div>
              <div className="flex gap-2 items-center">
                <div className="w-10 h-10 rounded border" style={{backgroundColor: `rgb(${r},${g},${b_})`}}></div>
                <button onClick={() => startEditColor(color)} className="bg-blue-500 text-white px-2 py-1 rounded">Edit</button>
                <button onClick={() => deleteColor(color.id)} className="bg-red-500 text-white px-2 py-1 rounded">Delete</button>
              </div>
            </div>
          );
        })}
      </div>
    </main>
  );
}